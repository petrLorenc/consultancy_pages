import sys

print(sys.modules)