def foo():
    ...

def bar():
    Ellipsis

print(bool(...))
print(bool(Ellipsis))