a = b = []
a.append(1)
b.append(2)
print(a)
print(b)

a = []
b = []
a.append(1)
b.append(2)
print(a)
print(b)