x = {1: "a", 1.0: "b"}
print(x[1])
print(x[1.0])
