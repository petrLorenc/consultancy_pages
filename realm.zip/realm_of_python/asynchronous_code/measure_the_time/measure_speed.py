"""
time python measure_speed.py
"""

def heavy_work():
    for _ in range(100_000_000):
        pass


if __name__ == '__main__':
    heavy_work()
