def get_llm():
    return "apiGPTeal"