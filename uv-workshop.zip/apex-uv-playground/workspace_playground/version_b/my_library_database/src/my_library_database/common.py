def get_connection():
    return "sqlite:///:memory:"