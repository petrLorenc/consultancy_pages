Steps:

* build (`uv build`)
* unzip (`python -m zipfile --extract dist/multiple_files-0.1.0-py3-none-any.whl unzipped_folder`)
* install (`uv pip`)
* check site-packages