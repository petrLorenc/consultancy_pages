def main():
    print("Hello from my-application!")


if __name__ == "__main__":
    main()
