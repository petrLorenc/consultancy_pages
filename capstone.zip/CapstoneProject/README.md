### Architecture used for GenAI bootcamp 03/2024

It enables switching adapter in real time (LoRA fine-tuned version of Mistral). Measurement shows that switching adapter is in about **50ms**. Can be beneficial when we decide to fine-tune our model (per project/department) with money-saving architecture. 

Still need to be answered:
* Is the memory/GPU advantage worth possible utilisation problems (two request on the different adapters in the same time - probably need to be solved by clever batching -> increased response time)

Setting for the first run:
```shell
cd ./database_server
conda activate pytorch
python load_msl_into_db.py
python load_vulgarism_into_db.py # if you want to use vulgarism list as profanity filtering
```

To run all servers (minimal version):
```shell
# set path to adapters in server/.env

docker compose up -d # start MLFlow (not needed for inference) and PostgresDB

tmux new -t database_server
conda activate pytorch
cd ft-lab/llm/my_code/database_server/
flask --app server.py run -h localhost -p 9002 --debug

tmux new -t inference_server
conda activate pytorch
cd ft-lab/llm/my_code/server/
flask --app model_serving.py run -h localhost -p 9001 --debug

tmux new -t frontend
conda activate pytorch
cd ft-lab/llm/my_code/frontend
streamlit run chatbot_ui.py --server.port 8888 --server.address localhost --browser.gatherUsageStats False
```

Additionally you can run

```shell
tmux new -t frontend-monitoring
conda activate pytorch
cd ft-lab/llm/my_code/frontend
streamlit run monitoring_ui.py --server.port 8889 --server.address localhost --browser.gatherUsageStats False

tmux new -t monitoring-thread
conda activate pytorch
cd ft-lab/llm/my_code/server
python monitoring_thread.py
```

### Diagram of architecture

![Architecture](img/adapter_switching_architecture.png)