"""
 ~/PycharmProjects/CapstoneProject  rsync -azuv --exclude="*mistral-7b-int4*" . bootcamp:~/
"""

import gc
import json
import time
import random
from typing import Tuple

import torch

import mlflow
from trl import SFTTrainer
from transformers import TrainingArguments
from datasets import load_dataset, Dataset
from sklearn.model_selection import train_test_split
from peft import LoraConfig, prepare_model_for_kbit_training, get_peft_model
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig


mlflow.set_tracking_uri(uri="http://localhost:5000")
mlflow.set_experiment("Fine-tuning Mistral Continue")
mlflow.autolog(log_models=False, log_datasets=False, log_model_signatures=False, log_input_examples=False)


def load_modified_dataset(name, rename_dict=None, subsample=None, dataset_kwarg=None, trainset_size=0.8) -> Tuple:
    if not dataset_kwarg:
        dataset_kwarg = {}
    dataset = load_dataset(name, split="train", **dataset_kwarg)
    df = dataset.to_pandas()
    df["type"] = name
    if rename_dict is not None:
        df = df.rename(columns=rename_dict)
        df["context"] = df["context"].map(lambda x: "".join(x["contexts"]))
    else:
        # Keep entries with correct answer as well
        df = df[(df["category"].isin(["closed_qa", "information_extraction", "open_qa"]))]
        df = df[df["context"].notnull()]

    if subsample:
        df = df.sample(n=subsample, random_state=42)

    if trainset_size:
        train_df, valid_df = train_test_split(df, test_size=(1 - trainset_size))
    else:
        train_df, valid_df = df, df

    train_dataset = Dataset.from_pandas(train_df[["instruction", "context", "response", "type"]], preserve_index=False)
    validation_dataset = Dataset.from_pandas(
        valid_df[["instruction", "context", "response", "type"]], preserve_index=False
    )

    return train_dataset, validation_dataset


def format_instruction(sample: dict) -> str:
    """Combine a row to a single str"""
    return random.choice(
        [
            f"""### Context:
{sample['context']}

### Question:
Using only the context above, {sample['instruction']}

### Response:
{sample['response']}

Trained by Petr Lorenc (taken from {sample['type']})
""",
            f"""### Context:
{sample['context']}

### Question:
{sample['instruction']}

### Response:
{sample['response']}

Trained by Petr Lorenc (taken from {sample['type']})
""",
            f"""### Context:
{sample['context']}

### Question:
Using only the context above, {sample['instruction']}

### Response:
{sample['response'].replace('?', '').lower()}

Trained by Petr Lorenc (taken from {sample['type']})
""",
            f"""### Context:
{sample['context']}

### Question:
{sample['instruction'].lower()}

### Response:
{sample['response'].replace('?', '').lower()}

Trained by Petr Lorenc (taken from {sample['type']})
""",
            f"""{sample['context']}

{sample['instruction'].lower()}

{sample['response'].replace('?', '').lower()}

Trained by Petr Lorenc (taken from {sample['type']})
""",
            f"""{sample['context']}

{sample['instruction'].lower()}

{sample['response'].lower()}

Trained by Petr Lorenc (taken from {sample['type']})
""",
        ]
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--output_dir", type=str, required=True, help="output path for the model")
    parser.add_argument("--checkpoint_dir", type=str, default="", required=False, help="output path for the model")
    parser.add_argument("--dataset", type=str, required=True, help="id of dataset from HF")
    parser.add_argument("--learning_rate", type=float, default=1e-3)
    parser.add_argument("--epochs", type=int, default=2)

    args = parser.parse_args()
    dataset = args.dataset
    output_dir = args.output_dir
    learning_rate = args.learning_rate
    epochs = args.epochs
    checkpoint_dir = args.checkpoint_dir
    print(args)

    # Actual code
    if dataset == "dolly":
        hf_train_dataset, hf_valid_dataset = load_modified_dataset("databricks/databricks-dolly-15k")
    elif dataset == "pubmed":
        hf_train_dataset, hf_valid_dataset = load_modified_dataset(
            "qiaojin/PubMedQA",
            rename_dict={"question": "instruction", "long_answer": "response"},
            subsample=15_000,
            dataset_kwarg={"name": "pqa_artificial"},
        )
    else:
        raise NotImplementedError(f"`{dataset}` is not supported")

    # Hugging Face Base Model ID
    model_id = "mistralai/Mistral-7B-v0.1"
    is_peft = False

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_use_double_quant=False,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
    )

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        low_cpu_mem_usage=True,
        torch_dtype=torch.float16,
        quantization_config=bnb_config,
        use_flash_attention_2=True,
    )

    model.config.pretraining_tp = 1

    tokenizer = AutoTokenizer.from_pretrained(model_id)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    # LoRA config for QLoRA
    peft_config = LoraConfig(
        lora_alpha=16,
        lora_dropout=0.1,
        r=8,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["v_proj", "down_proj", "up_proj", "o_proj", "q_proj", "gate_proj", "k_proj"],
    )

    # prepare model for training with low-precision
    model = prepare_model_for_kbit_training(model)
    model = get_peft_model(model, peft_config)
    # print(model)

    args = TrainingArguments(
        output_dir=output_dir + "_lr_" + str(learning_rate) + "_epochs_" + str(epochs) + f"_{dataset}",
        num_train_epochs=epochs,  # number of training epochs
        evaluation_strategy="steps",
        eval_steps=2,
        per_device_train_batch_size=5,  # batch size per batch
        per_device_eval_batch_size=5,
        gradient_accumulation_steps=2,  # effective batch size
        gradient_checkpointing=True,
        gradient_checkpointing_kwargs={"use_reentrant": True},
        optim="paged_adamw_32bit",
        logging_steps=1,  # log the training error every 10 steps
        save_strategy="steps",
        save_total_limit=2,  # save 2 total checkpoints
        ignore_data_skip=True,
        save_steps=5,  # save a checkpoint every 5 steps
        learning_rate=learning_rate,
        bf16=True,
        tf32=True,
        max_grad_norm=1.0,
        warmup_steps=5,
        lr_scheduler_type="constant",
        disable_tqdm=True,
    )

    # https://huggingface.co/docs/trl/sft_trainer#packing-dataset--constantlengthdataset-
    # max seq length for packing
    max_seq_length = 2048
    trainer = SFTTrainer(
        model=model,
        train_dataset=hf_train_dataset,
        eval_dataset=hf_valid_dataset,
        tokenizer=tokenizer,
        max_seq_length=max_seq_length,
        packing=True,
        formatting_func=format_instruction,  # our formatting function which takes a dataset row and maps it to str
        args=args,
    )

    start = time.time()
    if checkpoint_dir:
        trainer.train(resume_from_checkpoint=checkpoint_dir)  # progress bar is fake due to packing
    else:
        trainer.train(resume_from_checkpoint=False)  # progress bar is fake due to packing
    trainer.save_model()
    end = time.time()
    print(f"{end - start}s")
    # cleaning
    trainer = None
    gc.collect()
    torch.cuda.empty_cache()
