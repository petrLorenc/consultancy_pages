#!/bin/bash
# output_dir, learning_rate, epochs, dataset

#python train_adapter_mixtral.py ./mistral_7b_int4 1e-3 1 dolly
#python train_adapter_mixtral.py ./mistral_7b_int4 1e-3 1 pubmed
#
#python train_adapter_mixtral.py ./mistral_7b_int4 1e-4 1 dolly
#python train_adapter_mixtral.py ./mistral_7b_int4 1e-4 1 pubmed
#
#python train_adapter_mixtral.py ./mistral_7b_int4 1e-3 2 dolly
#python train_adapter_mixtral.py ./mistral_7b_int4 1e-3 2 pubmed

#python train_adapter_mixtral.py --output_dir ./mistral_new_7b_int4 --learning_rate 1e-4 --epochs 2 --dataset dolly
#python train_adapter_mixtral.py --output_dir ./mistral_new_7b_int4 --learning_rate 1e-4 --epochs 2 --dataset pubmed

python train_adapter_mixtral.py --output_dir ./mistral_continued_7b_int4 --checkpoint_dir ./mistral_contined_7b_int4_lr_0.0001_epochs_4_dolly/checkpoint-255 --learning_rate 1e-4 --epochs 6 --dataset dolly
#python train_adapter_mixtral.py --output_dir ./mistral_continued_7b_int4 --checkpoint_dir ../mistral_7b_int4_lr_0.001_epochs_3_pubmed/checkpoint-310/ --learning_rate 1e-4 --epochs 4 --dataset pubmed