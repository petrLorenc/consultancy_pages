import json
import glob
from langchain.document_loaders import PyPDFLoader
from pydantic import BaseModel, Field

no_langchain_documents = []


class Document(BaseModel):
    content: str
    source: dict


for path in glob.glob("original_synthetic_data/*.pdf"):
    # print("Processing ", path)
    loader = PyPDFLoader(path)
    documents = loader.load()

    no_langchain_documents.append(
        Document(content="\n".join([document.page_content for document in documents]), source=documents[0].metadata)
    )


# %%
with open("original_synthetic_data/data.json", "w") as f:
    json.dump([x.model_dump() for x in no_langchain_documents], f)
