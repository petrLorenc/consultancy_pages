```shell
scp -r -i /Users/lorencp/Documents/GenAI_bootcamp/capstone_project/PragueKeyPairs/Prague-bootcamp.pem -o "ProxyCommand=nc -X connect -x webproxy.merck.com:8080 %h %p" ubuntu@ec2-52-59-171-97.eu-central-1.compute.amazonaws.com:/home/ubuntu/ft-lab/llm/my_code/synthetic_data .
```