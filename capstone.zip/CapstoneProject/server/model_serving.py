import os
import time
from threading import Thread
from typing import List, Tuple

import requests
import torch
from peft import PeftModel
from dotenv import load_dotenv
from transformers import pipeline
from flask import Flask, Response, stream_with_context, request, jsonify
from transformers import AutoModelForCausalLM, AutoTokenizer, TextIteratorStreamer, BitsAndBytesConfig

load_dotenv()
app = Flask(__name__)

DATABASE_PORT = 9002
SENTIMENT_MODEL = "cardiffnlp/twitter-roberta-base-sentiment-latest"
LAST_CONTEXT = ""

adapters = [
    ("mistral_7b_int4_lr_0,001_epochs_1_pubmed", "../trained_models/mistral_7b_int4_lr_0.001_epochs_1_pubmed"),
    (
        "mistral_7b_int4_lr_0,001_epochs_3_pubmed",
        "../trained_models/mistral_7b_int4_lr_0.001_epochs_3_pubmed/checkpoint-310/",
    ),
    ("mistral_7b_int4_lr_0,0001_epochs_1_dolly", "../trained_models/mistral_7b_int4_lr_0.0001_epochs_1_dolly"),
    ("mistral_7b_int4_lr_0,001_epochs_2_dolly", "../trained_models/mistral_7b_int4_lr_0.001_epochs_2_dolly"),
    ("mistral_7b_int4_lr_1e-05_epochs_5_dolly", "../trained_models/mistral_7b_int4_lr_1e-05_epochs_5_dolly"),
    ("mistral_7b_int4_lr_0,0001_epochs_1_pubmed", "../trained_models/mistral_7b_int4_lr_0.0001_epochs_1_pubmed"),
    ("mistral_7b_int4_lr_0,001_epochs_2_pubmed", "../trained_models/mistral_7b_int4_lr_0.001_epochs_2_pubmed"),
    (
        "mistral_7b_int4_lr_1e-05_epochs_5_pubmed",
        "../trained_models/mistral_7b_int4_lr_1e-05_epochs_5_pubmed/checkpoint-330",
    ),
    ("mistral_7b_int4_lr_0,001_epochs_1_dolly", "../trained_models/mistral_7b_int4_lr_0.001_epochs_1_dolly"),
    ("mistral_7b_int4_lr_0,001_epochs_3_dolly", "../trained_models/mistral_7b_int4_lr_0.001_epochs_3_dolly"),
    #
    (
        "mistral_new_7b_int4_lr_0,0001_epochs_2_dolly",
        "../training_server/mistral_new_7b_int4_lr_0.0001_epochs_2_dolly/checkpoint-10",
    ),
    ("mistral_new_7b_int4_lr_0,0005_epochs_3_dolly", "../training_server/mistral_new_7b_int4_lr_0.0005_epochs_3_dolly"),
    ("mistral_new_7b_int4_lr_0,0001_epochs_2_dolly", "../training_server/backup/checkpoint-50"),
]


def load_model():
    model_id = "mistralai/Mistral-7B-v0.1"

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_use_double_quant=False,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
    )

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        low_cpu_mem_usage=True,
        torch_dtype=torch.float16,
        quantization_config=bnb_config,
        use_flash_attention_2=True,
    )

    model.config.pretraining_tp = 1

    tokenizer = AutoTokenizer.from_pretrained(model_id)
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    model = PeftModel.from_pretrained(model, adapters[0][1], adapter_name=adapters[0][0])
    for adapter_name, adapter_path in adapters[1:]:
        _ = model.load_adapter(adapter_path, adapter_name=adapter_name)
    return model, tokenizer


mistral_model, mistral_tokenizer = load_model()
mistral_model: PeftModel
mistral_tokenizer: AutoTokenizer
sentiment_task = pipeline("sentiment-analysis", model=SENTIMENT_MODEL, tokenizer=SENTIMENT_MODEL)

current_session = ""


def profanity_filtering(user_message: str) -> Tuple[bool, str]:
    """

    Args:
        user_message:

    Returns:

    """
    start_time = time.time()
    sentiment = sentiment_task(user_message)
    print(sentiment)
    if sentiment[0].get("label") == "negative" and sentiment[0].get("score") >= 0.5:
        return False, "Your message is very negative - be positive."

    vulgarism_detection = requests.post(
        f"http://localhost:{DATABASE_PORT}/get_documents", json={"query": user_message, "db": "vulgarism"}
    ).json()
    print(vulgarism_detection)
    if vulgarism_detection["scores"] and vulgarism_detection["scores"][0] < 0.25:  # more similar
        return False, "Vulgarism detected."

    requests.post(
        f"http://localhost:{DATABASE_PORT}/log", json={"_key": "profanity_time", "_value": time.time() - start_time}
    )
    return True, "OK"


@app.route("/like", methods=["POST"])
def process_like() -> None:
    """
    Just routing to database server
    Returns:

    """
    data = request.get_json(force=True)
    print(data)

    return requests.post(
        f"http://localhost:{DATABASE_PORT}/like",
        json={**data},
    ).json()


@app.route("/last_context", methods=["POST"])
def get_last_context() -> Response:
    """
    Just routing to database server
    Returns:

    """
    print(LAST_CONTEXT)
    return jsonify({"last_context": LAST_CONTEXT})


@app.route("/adapters", methods=["GET"])
def get_adapters() -> Response:
    """
    Just routing to database server
    Returns:

    """
    print([x[0] for x in adapters])
    return jsonify({"adapters": [x[0] for x in adapters]})


@app.route("/log", methods=["POST"])
def process_log() -> None:
    """
    Just routing to database server
    Returns:

    """
    data = request.get_json(force=True)
    print(data)

    return requests.post(
        f"http://localhost:{DATABASE_PORT}/log",
        json={**data},
    ).json()


@app.route("/generate/stream", methods=["POST"])
def generate_stream():
    """
    How to test curl -N -X POST -d '{"prompt" : "This is a test", "parameters" : {"max_new_tokens" : 100, "temperature" : 0.7, "do_sample" : true}}' http://localhost:5678/generate/stream?adapter_name=dolly
    Returns:

    """
    global_start_time = time.time()
    data = request.get_json(force=True)
    prompt: str = data["prompt"]
    session_id: str = data["session_id"]
    _id: str = data["_id"]
    k_doc: int = int(data["k_doc"])
    parameters: dict = data.get("parameters", {})
    template: str = parameters.get(
        "template",
        """### Context:
{context}

### Question:
Using only the context above, {question}

### Response:""",
    )
    global current_session
    current_session = session_id

    is_ok, message = profanity_filtering(prompt)
    if not is_ok:
        return message

    start_time = time.time()
    context = requests.post(
        f"http://localhost:{DATABASE_PORT}/get_documents", json={"query": prompt, "k_doc": k_doc}
    ).json()
    context = "\n".join([x for x in context["documents"]])
    global LAST_CONTEXT
    LAST_CONTEXT = context
    requests.post(
        f"http://localhost:{DATABASE_PORT}/log", json={"_key": "db_response_time", "_value": time.time() - start_time}
    )
    print(context)
    template = template.format(context=context, question=prompt)
    print(template)
    print("#" * 100)
    adapter_model = request.args.get("adapter_model", default="dolly", type=str)
    switching_adapter_time = time.time()
    mistral_model.set_adapter(adapter_model)
    print("switching adapter time", time.time() - switching_adapter_time)
    # Tokenize the input
    input_ids = mistral_tokenizer(template, return_tensors="pt", truncation=True, max_length=1500).input_ids.cuda()

    # Support for streaming of tokens within generate requires
    # generation to run in a separate thread
    streamer = TextIteratorStreamer(mistral_tokenizer, skip_prompt=True)
    generation_kwargs = dict(
        input_ids=input_ids,
        streamer=streamer,
        max_new_tokens=parameters.get("max_new_tokens", 100),
        do_sample=parameters.get("do_sample", True),
        top_p=parameters.get("top_p", 0.9),
        temperature=parameters.get("temperature", 0.7),
        use_cache=True,
    )

    thread = Thread(target=mistral_model.generate, kwargs=generation_kwargs)
    thread.start()

    def f():
        for r in streamer:
            if r.strip() == "</s>":
                break
            yield r

    response = Response(stream_with_context(f()), mimetype="text/event-stream")
    requests.post(
        f"http://localhost:{DATABASE_PORT}/log", json={"_key": "e2e_response_time", "_value": time.time() - start_time}
    )
    return response


if __name__ == "__main__":
    """
    tmux new -t inference_server
    conda activate pytorch
    cd ft-lab/llm/my_code/server/
    flask --app model_serving.py run -h localhost -p 9001 --debug
    ...
    tmux attach -t database_server
    """
    import sys

    app.run(host="0.0.0.0", port=int(sys.argv[1]))
