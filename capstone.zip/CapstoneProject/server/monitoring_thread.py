import time
import gpustat
import psutil
import requests

SERVER_PORT = 9001

if __name__ == "__main__":
    while True:
        try:
            gpu_stats = gpustat.new_query()
        except:
            gpu_stats = []
            utilisation = 0

        for gpu in gpu_stats:
            utilisation = gpu.entry["utilization.gpu"]
        cpu_percent = psutil.cpu_percent(percpu=False)

        total_ram = psutil.virtual_memory().total

        # Convert to human-readable format (e.g., GB)
        total_ram_gb = total_ram / (1024**3)

        requests.post(f"http://localhost:{SERVER_PORT}/log", json={"_key": "cpu_utilisation", "_value": cpu_percent})
        requests.post(f"http://localhost:{SERVER_PORT}/log", json={"_key": "gpu_utilisation", "_value": utilisation})
        requests.post(
            f"http://localhost:{SERVER_PORT}/log", json={"_key": "memory_utilisation", "_value": total_ram_gb}
        )
        print(cpu_percent)
        print(utilisation)
        print(total_ram_gb)
        time.sleep(2)
