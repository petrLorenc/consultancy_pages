import requests
import streamlit as st
import random
import time

import string

SERVER_PORT = 9001


def generate_random_string(length):
    # Define the characters to choose from (lowercase letters and digits)
    characters = string.ascii_lowercase + string.digits

    # Generate a random string of the specified length
    random_string = "".join(random.choice(characters) for _ in range(length))

    return random_string


def init_session():
    session_id = generate_random_string(64)
    # todo sent init session to the server
    return session_id


# Streamed response emulator
def response_generator(_prompt, _id):
    with requests.post(
        f"http://localhost:{SERVER_PORT}/generate/stream?adapter_model={st.session_state.adapter_name}",
        json={
            "session_id": st.session_state.session_id,
            "_id": _id,
            "prompt": _prompt,
            "k_doc": st.session_state.k_doc,
            "parameters": {
                "template": st.session_state.input_format,
                "max_new_tokens": st.session_state.max_tokens,
                "temperature": st.session_state.temperature,
            },
        },
        stream=True,
    ) as response:
        for line in response.iter_lines(decode_unicode=True):
            if line:
                yield line


def submit_opinion(_session_id: str, _message_id: str, _score: float):
    """
    _session_id: str = data["_session_id"]
    _message_id: str = data["_message_id"]
    _score: str = data["_score"]
    _used_adapter: str = data["_used_adapter"]
    kwargs = data.get("kwargs", {})
    Args:
        _session_id:
        _message_id:
        _score:

    Returns:

    """
    print(_session_id)
    print(_message_id)
    print(_score)
    r = requests.post(
        f"http://localhost:{SERVER_PORT}/like",
        json={
            "_session_id": _session_id,
            "_message_id": _message_id,
            "_score": _score,
            "_used_adapter": st.session_state.adapter_name,
            "_temperature": st.session_state.temperature,
            "_max_tokens": st.session_state.max_tokens,
        },
    ).json()
    print(r)


st.title("Simple chat")

with st.expander("Control"):
    if st.button("Clear chat!!!"):
        st.session_state.messages = []
        st.session_state.session_id = ""
    possible_adapters = requests.get(f"http://localhost:{SERVER_PORT}/adapters").json()["adapters"]
    st.session_state.adapter_name = st.radio("What adapter?", options=possible_adapters)
    st.session_state.temperature = st.slider("Temperature", 0.1, 2.0, 1.0, step=0.1)
    st.session_state.max_tokens = st.slider("Max tokens", 1, 1024, 512, step=10)
    st.session_state.k_doc = st.slider("# Documents", 1, 5, 2, step=1)
    st.session_state.input_format = st.text_area(
        "Input format",
        """### Context:
{context}

### Question:
Using only the context above, {question}

### Response:""",
        disabled=True,
    )
    to_be_filled = st.empty()


# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []
if "session_id" not in st.session_state:
    st.session_state.session_id = ""

# Display chat messages from history on app rerun
for message in st.session_state.messages:
    _id = message["_id"]
    with st.chat_message(message["role"]):
        col1, col2, col3 = st.columns([6, 0.5, 0.5])
        with col1:
            st.markdown(message["content"])
        if message["role"] != "user":
            with col2:
                st.button(
                    ":thumbsup:", key=f"up_{_id}", on_click=submit_opinion, args=(st.session_state.session_id, _id, 1.0)
                )

            with col3:
                st.button(
                    ":thumbsdown:",
                    key=f"down_{_id}",
                    on_click=submit_opinion,
                    args=(st.session_state.session_id, _id, -1.0),
                )

# Accept user input
if prompt := st.chat_input("What is up?"):
    # Add user message to chat history
    new_id = len(st.session_state.messages) and st.session_state.messages[-1].get("_id", -1) + 1
    if new_id == 0:
        st.session_state.session_id = init_session()
    session_id = st.session_state.session_id

    st.session_state.messages.append({"session_id": session_id, "_id": new_id, "role": "user", "content": prompt})
    # Display user message in chat message container
    with st.chat_message("user"):
        st.markdown(prompt)

    new_id = st.session_state.messages[-1].get("_id", -1) + 1
    # Display assistant response in chat message container
    with st.chat_message("assistant"):
        col1, col2, col3 = st.columns([6, 0.5, 0.5])
        with col1:
            requests.post(
                f"http://localhost:{SERVER_PORT}/log",
                json={"_key": "messages", "_value": prompt, "_session": st.session_state.session_id},
            )
            response = st.write_stream(response_generator(prompt, new_id))
            requests.post(
                f"http://localhost:{SERVER_PORT}/log",
                json={"_key": "messages", "_value": response, "_session": st.session_state.session_id},
            )
        with col2:
            st.button(
                ":thumbsup:",
                key=f"up_{new_id}",
                on_click=submit_opinion,
                args=(st.session_state.session_id, new_id, 1.0),
            )
        with col3:
            st.button(
                ":thumbsdown:",
                key=f"down_{new_id}",
                on_click=submit_opinion,
                args=(st.session_state.session_id, new_id, -1.0),
            )

    # Add assistant response to chat history
    st.session_state.messages.append(
        {"session_id": session_id, "_id": new_id, "role": "assistant", "content": response}
    )
# not best idea
r = requests.post(
    f"http://localhost:{SERVER_PORT}/last_context",
    json={"_session": st.session_state.get("session_id", "")},
).json()
used_context = r.get("last_context", "")
print(used_context)
to_be_filled.text_area("Used context", value=used_context, disabled=True)
