"""
streamlit run monitoring_ui.py --server.port 8889 --server.address localhost --browser.gatherUsageStats False
"""

import json

import pandas as pd
import plotly.express as px
import requests
import streamlit as st

LOCAL = True
DATABASE_PORT = 5002

if st.button("Generate performance graphs"):
    st.header("Like metrics")
    if not LOCAL:
        likes = requests.get(f"http://localhost:{DATABASE_PORT}/likes")
        logs = requests.get(f"http://localhost:{DATABASE_PORT}/logs")
    else:
        with open("../database_server/old/likes.json", "r") as f:
            likes = json.load(f)
        with open("../database_server/old/logs.json", "r") as f:
            logs = json.load(f)

    grouped = []
    for specific_session in likes.values():
        grouped.extend(list(specific_session.values()))

    print(grouped)
    # data = [(3, 'a'), (2, 'b'), (1, 'c'), (0, 'd')]
    # pd.DataFrame.from_records(data, columns=['col_1', 'col_2'])
    df = pd.DataFrame.from_records(grouped)
    df["point"] = 1
    print(df)
    fig = px.pie(df, names="_used_adapter", values="point", height=400, title="Usage of adapter")
    st.write("Showing what adapter was chosen when we record feedback.")
    # Plot!
    st.plotly_chart(fig, use_container_width=True)
    st.write("Showing what was the score (+/-) of chosen adapter.")
    fig2 = px.histogram(
        df, x="_used_adapter", y="point", color="_score", barmode="group", height=400, title="Likes per adapter"
    )
    st.write("")
    # Plot!
    st.plotly_chart(fig2, use_container_width=True)

    st.header("HW Performance")

    for key in ["cpu_utilisation", "gpu_utilisation", "memory_utilisation"]:
        df = pd.DataFrame.from_dict(
            {"value": [x["value"] for x in logs[key]], "time": [x for x in range(len(logs[key]))]}
        )

        fig = px.line(df, x="time", y="value", height=400, title=key)
        st.plotly_chart(fig, use_container_width=True)

    st.header("Time performance")
    st.write("db_response_time - response time of searching in DB in RAG")
    st.write("e2e_response_time - response time from the moment sending the prompt till full response")
    st.write("profanity_time - response time of searching in DB for match with vulgarism + sentiment analysis")
    for key in ["db_response_time", "e2e_response_time", "profanity_time"]:
        df = pd.DataFrame.from_dict(
            {"value": [x["value"] for x in logs[key]], "time": [0 for x in range(len(logs[key]))]}
        )

        fig = px.violin(df, x="time", y="value", height=400, title=key)
        st.plotly_chart(fig, use_container_width=True)
