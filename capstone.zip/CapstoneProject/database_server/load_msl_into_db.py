import json
import requests
from tqdm import tqdm

DATABASE_SERVER_PORT = 9002

data = []

with open("../data_creation/synthetic_data/data_v3.json") as f:
    data.extend(json.load(f))


with open("../data_creation/original_synthetic_data/data.json") as f:
    data.extend(json.load(f))


# for d in tqdm(data):
#     requests.post(
#         f"http://localhost:{DATABASE_SERVER_PORT}/add_documents", json={"documents": [d["content"]], "db": "msl"}
#     )

# for d in tqdm(data):
#     requests.post(
#         f"http://localhost:{DATABASE_SERVER_PORT}/add_documents",
#         json={
#             "documents": list(filter(lambda x: len(x) > 100, map(lambda x: x.strip(), d["content"].split("\n")))),
#             "db": "msl",
#         },
#     )
#
# for d in tqdm(data):
#     requests.post(
#         f"http://localhost:{DATABASE_SERVER_PORT}/add_documents",
#         json={
#             "documents": list(filter(lambda x: len(x) > 100, map(lambda x: x.strip(), d["content"].split("\n")))),
#             "db": "msl",
#         },
#     )

for d in tqdm(data):
    batch_size = 400
    chunks = []
    for start_idx in range((len(d["content"]) // batch_size)):
        chunks.append(d["content"][start_idx * batch_size : (start_idx + 1) * batch_size])
    print(chunks[0])
    requests.post(
        f"http://localhost:{DATABASE_SERVER_PORT}/add_documents",
        json={
            "documents": chunks,
            "db": "msl",
        },
    )
