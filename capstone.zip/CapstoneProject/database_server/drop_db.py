from langchain.vectorstores.pgvector import PGVector

CONNECTION_STRING = PGVector.connection_string_from_db_params(
    driver="psycopg2", host="localhost", port="5432", database="postgres", user="username", password="password"
)

# Creates the database connection to our existing DB
db = PGVector(connection_string=CONNECTION_STRING, collection_name="embeddings", embedding_function=None)

db.drop_tables()
