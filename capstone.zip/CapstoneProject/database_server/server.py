import json
import time
import pathlib
from typing import List, Tuple

from dotenv import load_dotenv
from flask import Flask, request, jsonify, Response
from langchain.docstore.document import Document
from langchain.vectorstores.pgvector import PGVector
from langchain.embeddings.sentence_transformer import SentenceTransformerEmbeddings


load_dotenv()
app = Flask(__name__)

LIKE_DATABASE = "likes.json"
LOG_DATABASE = "logs.json"

CONNECTION_STRING = PGVector.connection_string_from_db_params(
    driver="psycopg2", host="localhost", port="5432", database="postgres", user="username", password="password"
)

# The embedding function that will be used to store into the database
embedding_function = SentenceTransformerEmbeddings(
    model_name="BAAI/bge-large-en-v1.5", model_kwargs={"device": "cuda"}, encode_kwargs={"normalize_embeddings": True}
)

# Creates the database connection to our existing DB
db = PGVector(connection_string=CONNECTION_STRING, collection_name="embeddings", embedding_function=embedding_function)
vulgarism_db = PGVector(
    connection_string=CONNECTION_STRING, collection_name="vulgarism", embedding_function=embedding_function
)


@app.route("/like", methods=["POST"])
def process_like() -> Response:
    data = request.get_json(force=True)
    print(data)
    _session_id: str = data["_session_id"]
    _message_id: str = data["_message_id"]
    _score: str = data["_score"]
    _used_adapter: str = data["_used_adapter"]
    kwargs = data.get("kwargs", {})

    if pathlib.Path(LIKE_DATABASE).exists():
        with open(LIKE_DATABASE, "r") as f:
            likes: dict = json.load(f)

    # todo: not optimal to rewrite whole
    likes.setdefault(_session_id, {})[_message_id] = {
        "_score": _score,
        "_used_adapter": _used_adapter,
        **kwargs,
        "time": time.time(),
    }

    with open(LIKE_DATABASE, "w") as f:
        json.dump(likes, f)

    return jsonify({"status": 200})


@app.route("/likes", methods=["GET"])
def get_likes() -> Response:
    if pathlib.Path(LOG_DATABASE).exists():
        with open(LOG_DATABASE, "r") as f:
            logs: dict = json.load(f)

    return jsonify(logs)


@app.route("/log", methods=["POST"])
def process_log() -> Response:
    data = request.get_json(force=True)
    _key: str = data["_key"]
    _value: str = data["_value"]
    _session_id: str = data.get("_session_id", "")
    kwargs = data.get("kwargs", {})

    if pathlib.Path(LOG_DATABASE).exists():
        with open(LOG_DATABASE, "r") as f:
            logs: dict = json.load(f)

    # todo: not optimal to rewrite whole
    logs.setdefault(_key, []).append({"value": _value, "session": _session_id, **kwargs, "time": time.time()})

    with open(LOG_DATABASE, "w") as f:
        json.dump(logs, f)

    return jsonify({"status": 200})


@app.route("/logs", methods=["GET"])
def get_logs() -> Response:
    if pathlib.Path(LIKE_DATABASE).exists():
        with open(LIKE_DATABASE, "r") as f:
            likes: dict = json.load(f)

    return jsonify(likes)


@app.route("/get_documents", methods=["POST"])
def inference():
    """
    curl -X POST -d '{"query" : "test"}' http://localhost:5678/get_documents
    Returns:

    """
    data = request.get_json(force=True)
    if data.get("db") == "vulgarism":
        docs_with_scores = vulgarism_db.similarity_search_with_score(data["query"], k=1)
    else:
        k_doc = data.get("k_doc", 3)
        docs_with_scores = db.similarity_search_with_score(data["query"], k=k_doc)
    print(docs_with_scores)
    docs_with_scores = sorted(
        docs_with_scores,
        key=lambda x: x[1],
    )

    return jsonify(
        {
            "documents": [datapoint[0].page_content for datapoint in docs_with_scores],
            "scores": [datapoint[1] for datapoint in docs_with_scores],
        }
    )


@app.route("/add_documents", methods=["POST"])
def adding_docs():
    """
    curl -X POST -d '{"documents" : ["This is a test", "Another documents"]}' http://localhost:5678/add_documents
    Returns:

    """
    data = request.get_json(force=True)
    assert "documents" in data, "Pass documents into request {'documents': []}"
    assert isinstance(data["documents"], list), "Pass list of documents into request {'documents': [doc1, doc2]}"

    if data.get("db") == "vulgarism":
        print("Saving into Vulgarism DB!")
        res = vulgarism_db.add_documents([Document(page_content=datapoint) for datapoint in data["documents"]])
    else:
        res = db.add_documents([Document(page_content=datapoint) for datapoint in data["documents"]])
    print(f"Added {len(res)} embeddings.")

    return jsonify({"res": f"Added {len(res)} embeddings."})


print("everything is set!")

if __name__ == "__main__":
    """
    tmux new -t database_server
    conda activate pytorch
    cd ft-lab/llm/my_code/database_server/
    flask --app server.py run -h localhost -p 9002 --debug
    ...
    tmux attach -t database_server
    """
    import sys

    app.run(host="0.0.0.0", port=int(sys.argv[1]))
