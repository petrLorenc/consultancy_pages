import random

import requests
from tqdm import tqdm

DATABASE_SERVER_PORT = 9002

with open("vulgarism_list.txt") as f:
    all_vulgarism = f.readlines()

all_vulgarism = random.sample(all_vulgarism, k=250)

requests.post(
    f"http://localhost:{DATABASE_SERVER_PORT}/add_documents", json={"documents": all_vulgarism, "db": "vulgarism"}
)
