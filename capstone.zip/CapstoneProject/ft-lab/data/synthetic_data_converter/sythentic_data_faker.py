import csv
from faker import Faker
import random

fake = Faker()

# Load real city and state names
with open('address.txt', 'r') as file:
    address = [line.strip() for line in file.readlines()]

# Load real hospital names
with open('hospitals.txt', 'r') as file:
    hospitals = [line.strip() for line in file.readlines()]

# Load real city names
with open('city.txt', 'r') as file:
    city = [line.strip() for line in file.readlines()]

# Load real medication names
with open('medications.txt', 'r') as file:
    drugs = [line.strip() for line in file.readlines()]

def generate_patient_data():
    patient_id = fake.uuid4()
    full_name = fake.name()
    age = fake.random_int(min=18, max=90)
    dob = fake.date_of_birth()
    place_of_birth = random.choice(city)
    gender = fake.random_element(elements=('Male', 'Female'))
    ms_date_of_onset = fake.date_between(start_date='-10y', end_date='today')
    ms_age_of_onset = fake.random_int(min=18, max=90)
    ms_diagnosis_date = fake.date_between(start_date='-5y', end_date='today')
    still_alive = fake.random_element(elements=('Yes', 'No'))
    age_of_death = None if still_alive == 'Yes' else fake.random_int(min=ms_age_of_onset, max=90)
    
    # Generate real-sounding medication data
    medication_name = random.choice(drugs)
    dose_of_medication = fake.random_element(elements=('10 mg', '20 mg', '80 mg'))
    manufacturer = fake.company()

    hospital_visited = random.choice(hospitals)
    full_address = random.choice(address)
    genetically_tested = fake.random_element(elements=('Yes', 'No'))
    genetic_mutation = fake.random_element(elements=('SOD1', 'TMEM230', 'APOE1', 'APOE2'))
    family_member_diagnosed_ms = fake.random_element(elements=('Yes', 'No'))
    family_member_diagnosed_other = fake.random_element(elements=('Yes', 'No'))

    return [
        patient_id, 
        full_name, 
        age, 
        dob, 
        place_of_birth, 
        gender,
        ms_date_of_onset, 
        ms_age_of_onset, 
        ms_diagnosis_date,
        still_alive, age_of_death, 
        medication_name, 
        dose_of_medication,
        manufacturer, 
        hospital_visited, 
        full_address,
        genetically_tested, 
        genetic_mutation, 
        family_member_diagnosed_ms,
        family_member_diagnosed_other
    ]

def generate_table(num_rows):
    header = [
        "Patient ID", "Patient Full Name", 
        "Patient Age", "Date of Birth",
        "Place of Birth", "Gender", 
        "Multiple Sclerosis Date of Onset",
        "MS Age of Onset", 
        "MS Diagnosis Date", "Still Alive",
        "Age of Death (if not alive)", 
        "MS Medication Being Taken",
        "Dose of Medication", 
        "Manufacturer", 
        "Hospital Being Visited",
        "Patient Full Address", 
        "Was Patient Genetically Tested", 
        "Genetic Mutation for the Disease",
        "Was Any Other Family Member Diagnosed for Multiple Sclerosis",
        "Was Any Other Family Member Diagnosed for Other Neurodegenerative Disease"
    ]

    with open('mockup_data_with_real_names.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(header)

        for _ in range(num_rows):
            row = generate_patient_data()
            writer.writerow(row)

if __name__ == "__main__":
    generate_table(1000)