# Image Generation Model Practice

The `image-generation` project has a very simple example of using a `stable-diffusion` model for generating images from text.

1. `inference`
    Explore using stable-diffusion to generate images from text phrases.
