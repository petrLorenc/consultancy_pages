pip install packaging ninja
pip install flash-attn --no-build-isolation