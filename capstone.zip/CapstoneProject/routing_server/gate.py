import requests
from flask import Flask
from flask import request, jsonify
from dotenv import load_dotenv

"""
Used for routing communication from server to GPTeal
"""

load_dotenv()
app = Flask(__name__)

api_root = "https://iapi.merck.com/gpt/v2"


@app.route("/", methods=["POST"])
def foo():
    data = request.get_json()
    chat_model = request.args.get("chat_model", default="gpt-35-turbo-0301", type=str)
    print(f"INPUT ({chat_model}):", end="")
    print(data)

    resp = requests.post(
        url=f"{api_root}/{chat_model}/chat/completions",
        params={"api-version": "2023-05-15"},
        headers={"X-Merck-APIKey": "0sY323AZQLrSkHqbjkKXbC1MGdUAF9kX"},  # genAI bootcamp key
        json=data,
    )
    print("OUTPUT:", end="")
    print(resp.text)
    return jsonify(resp.json())


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7777)
