def main():
    print("Hello from backend-package! v3")


if __name__ == "__main__":
    main()
