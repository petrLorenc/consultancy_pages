def main():
    print("Hello from utils-package!")


if __name__ == "__main__":
    main()
