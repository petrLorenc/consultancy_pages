def main():
    print("Hello from other!")


if __name__ == "__main__":
    main()
