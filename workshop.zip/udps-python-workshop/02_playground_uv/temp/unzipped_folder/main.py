def main():
    print("Hello from code!")


if __name__ == "__main__":
    main()
