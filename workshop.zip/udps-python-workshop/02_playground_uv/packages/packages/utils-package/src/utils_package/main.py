def main():
    print("Hello from utils-package! v4")


if __name__ == "__main__":
    main()
