# contents of test_module.py with source code and the test
from pathlib import Path

def first_layer(bar=None):
    """First layer function."""
    return second_layer(bar)

def second_layer(bar):
    """Second layer function."""
    return "Something"

def getssh():
    """Simple function to return expanded homedir ssh path."""
    return Path.home() / ".ssh"