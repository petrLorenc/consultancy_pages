from pathlib import Path

from unittest.mock import patch
from unittest.mock import call

from pytest_testing.my_main_code import getssh, first_layer


def test_getssh(monkeypatch):
    # mocked return function to replace Path.home
    # always return '/abc'
    def mockreturn():
        return Path("/abc")

    # Application of the monkeypatch to replace Path.home
    # with the behavior of mockreturn defined above.
    monkeypatch.setattr(Path, "home", mockreturn)

    # Calling getssh() will use mockreturn in place of Path.home
    # for this test with the monkeypatch.
    x = getssh()
    assert x == Path("/abc/.ssh")


def test_sum():
    assert 2 == 2


@patch("pytest_testing.my_main_code.second_layer", return_value="Mocked")
def test_getssh_mocked(mock_second_layer):
    x = first_layer()
    assert x == "Mocked"
    x = first_layer(bar="passing")
    
    # Assert the mock was called
    assert mock_second_layer.called
    
    # Assert the number of calls
    assert mock_second_layer.call_count == 2
    
    # Check sequence of calls
    expected_calls = [
        call(None),
        call("passing")
    ]
    mock_second_layer.assert_has_calls(expected_calls, any_order=False)