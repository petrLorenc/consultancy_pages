from __future__ import annotations

import functools
import typing
import uuid
from typing import Annotated, Callable, Generic

T = typing.TypeVar("T")


def _infer_dependencies(func: Callable) -> dict[str, Depends]:
    annotations = typing.get_type_hints(func, include_extras=True)
    dependencies = {}
    for name, annotation in annotations.items():
        if hasattr(annotation, "__metadata__"):
            for metadata in annotation.__metadata__:
                if isinstance(metadata, Depends):
                    dependencies[name] = metadata
    return dependencies


class Depends(Generic[T]):
    def __init__(self, func: Callable[..., T]):
        self._deps = _infer_dependencies(func)
        self.func = func

    def solve(self) -> T:
        return self.func(
            **{name: dependency.solve() for name, dependency in self._deps.items()}
        )


def injectable(func):
    dependencies = _infer_dependencies(func)

    @functools.wraps(func)
    def _wrapper(*args, **kwargs):
        solved = {name: dependency.solve() for name, dependency in dependencies.items()}

        return func(*args, **{**kwargs, **solved})

    return _wrapper


if __name__ == "__main__":
    # Example flat usage
    def a():
        return 1

    def b():
        return 2

    @injectable
    def example_function(
        _a: Annotated[int, Depends(b)], _b: Annotated[int, Depends(b)]
    ) -> int:
        return _a + _b

    print(example_function())  # Output: 3

    # Example nested usage

    def c():
        return 3

    def d(_c: Annotated[int, Depends(c)]):
        return _c + 4

    @injectable
    def example_function_nested(
        _c: Annotated[int, Depends(c)], _d: Annotated[int, Depends(d)]
    ) -> int:
        return _c + _d

    print(example_function_nested())  # Output: 10
