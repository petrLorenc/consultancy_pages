import sys
sys.path.insert(0, 'project_1')
sys.path.insert(0, 'project_2')

# becuase of namespace package, we can import from both projects from same namespace
# if we would use __init__.py files, only one would work
from something.my_file_1 import bar
from something.my_file_2 import foo

foo()
bar()