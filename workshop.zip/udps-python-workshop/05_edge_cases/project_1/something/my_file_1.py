def bar():
    print("Hello, World! From project_1")