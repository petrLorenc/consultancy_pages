def foo():
    print("Hello, World! From project_2")