# UDPS Python 101 workshop

Python is a high-level, interpreted programming language known for its readability and simplicity, which makes it an excellent choice for both beginners and experienced developers. Created by Guido van Rossum and first released in 1991, Python supports multiple programming paradigms, including procedural, object-oriented, and functional programming. Its extensive standard library and vibrant ecosystem of third-party packages allow for versatility in various applications, from web development and data analysis to artificial intelligence and scientific computing. Python's syntax prioritizes clarity and efficiency, enabling developers to express concepts in fewer lines of code compared to many other languages. As a result, it has become one of the most popular programming languages in the world, with a large community and active support.

## Agenda

### Session 1 & Session 2
- Introduction to Python (Syntax) 
  - Jupyter Notebook (over Docker) or locally
  - lecture format with time for experiments
  - See below for more details ...
  
### Session 3
- Virtual Environment
  - Where the Python looks for modules
  - Docker container with UV installed or locally
  - lecture format with time for experiments
  - [ ] Python Virtual Environment with focus on UV
  - [ ] Structure/Packaging - setuptools, pyproject.toml, setup.cfg, MANIFEST.in

- Tools/Libraries on real project
  - Assignments over real project
  - [ ] Tools for better development - pytest, black, flake8, mypy, isort
  - [ ] Tools for debugging - PyCharm
  - [ ] Tools for documentation - Sphinx
  - [ ] Libraries - Langchain, fastAPI, asyncio, pydantic 
- 
- Keep for future
  - pre-commit
  - [ ] Tools to measure performance - cProfile, timeit, memory_profiler
  - [ ] Tools for debugging - VSCode
  - [ ] Tools for packaging - setuptools, wheel, twine
  - [ ] Tools for experimentation - Jupyter Notebook

### Introduction to Python - Session 1 & Session 2

See `01_playground` folder for examples.

#### Part 1
- [ ] PEP 8 (Style Guide for Python Code)
- [ ] Built-in functions (print, input, len, type, range, open, etc.)
- [ ] Comprehensions
- [ ] Data types (int, float, str, bool, list, tuple, dict, set)
- [ ] Control Flow (if, elif, else, for, while, break, continue, pass)
- [ ] Exception Handling (try, except, else, finally, raise)
- [ ] Functions (type hints, deepcopy), Lambda Functions

#### Part 2
- [ ] Classes and Objects, dunder methods (class, self, __init__, inheritance, super, etc.)

#### Part 3
- [ ] Lambda Functions
- [ ] Generators
- [ ] Context Managers - File Handling (open, read, write, close)
- [ ] Decorators
- [ ] Parallelism 

### Virtual Environment - Session 3
- [ ] Modules/Imports (import, from, as)

See `02_playground_uv`.

### Tools/Libraries on real project - Session 3

See `src` folder. Main point of interest is makefile.

Linters/Formatters:
* https://pypi.org/project/isort/
* https://black.readthedocs.io/en/stable/index.html
* https://www.pydocstyle.org/en/stable/usage.html#configuration-files
* https://pypi.org/project/autoflake/
* https://www.pydocstyle.org/en/stable/

Docs:
* https://www.sphinx-doc.org/en/master/
* https://myst-parser.readthedocs.io/en/latest/intro.html
* https://sphinx-autodoc2.readthedocs.io/en/latest/

Specific:
* https://docs.pydantic.dev/latest/api/base_model/
* https://www.langchain.com/
* https://loguru.readthedocs.io/en/stable/overview.html#ready-to-use-out-of-the-box-without-boilerplate
* https://fastapi.tiangolo.com/
* https://jupyter.org/

# Terminology

- **Duck typing** - Duck typing is a concept related to dynamic typing, where the type or the class of an object is less important than the methods it defines. When you use duck typing, you do not check types at all. Instead, you check for the presence of a given method or attribute.
  - This term says that if you have an object that looks like a duck, walks like a duck, and quacks like a duck, then it must be a duck!
  
- **Method Resolution Order (MRO)** -  


# Internal Links

* https://share.merck.com/spaces/DG/pages/1884820019/Python+development
* https://share.merck.com/spaces/DSP/pages/1853711437/Python+learning+path
* https://github.com/merck-gen/pycom-fastapi-template


# External Links

* https://fastapi.tiangolo.com/virtual-environments/
* https://www.loopwerk.io/articles/2024/python-poetry-vs-uv/ + https://www.loopwerk.io/articles/2024/python-uv-revisited/ + https://github.com/astral-sh/uv/issues/1474
* https://pythontutor.com/visualize.html
* https://hynek.me/articles/testing-packaging/ 