from langfuse import Langfuse

langfuse = Langfuse(
  secret_key="sk-lf-b79d87c4-c04f-42b4-9ade-aa7127a3648f",
  public_key="pk-lf-d41699bd-51d5-4c2c-b120-96e879f4bee2",
  host="http://internal-langfuse-web-185828690.us-east-1.elb.amazonaws.com"
)

# Create generation in Langfuse
generation = langfuse.generation(
    name="summary-generation",
    model="gpt-4o",
    model_parameters={"maxTokens": "1000", "temperature": "0.9"},
    input=[{"role": "system", "content": "You are a helpful assistant."}, {"role": "user", "content": "Please generate a summary of the following documents \nThe engineering department defined the following OKR goals...\nThe marketing department defined the following OKR goals..."}],
    metadata={"interface": "whatsapp"}
)
 
# Execute model, mocked here
# chat_completion = openai.ChatCompletion.create(model="gpt-4o", messages=[{"role": "user", "content": "Hello world"}])
chat_completion = {"completion":"The Q3 OKRs contain goals for multiple teams..."}
 
# Update span and sets end_time
generation.end(output=chat_completion)
 
# The SDK executes network requests in the background.
# To ensure that all requests are sent before the process exits, call flush()
# Not necessary in long-running production code
langfuse.flush()