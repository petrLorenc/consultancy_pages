"""
In certain circumstances, you may not need the strict rules of a formal Python interface.
Python’s dynamic nature allows you to implement an informal interface.
An informal Python interface is a class that defines methods that can be overridden,
but there’s no strict enforcement.

To create a formal interface you need to use abc module.
"""

import abc
import os
from abc import ABCMeta
from typing import Protocol

from langchain.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI
from pydantic import BaseModel, Field
from typing_extensions import runtime_checkable

from udps_python_utils.extractors import extract_json


@runtime_checkable
class LLMModel(Protocol):
    """
    Informal interface
    See `playground/playground_interface.py` for more details
    """

    def invoke(self, *args, **kwargs): ...

    def __call__(self, *args, **kwargs):
        return self.invoke(*args, **kwargs)


class LangchainLLM:
    """
    # it require ADAPTER pattern https://refactoring.guru/design-patterns/adapter/python/example#lang-features
    """

    def __init__(self, azure_chat_open_ai: AzureChatOpenAI):
        self.azure_chat_open_ai = azure_chat_open_ai

    def invoke(self, *args, **kwargs):
        self.azure_chat_open_ai.invoke(*args, **kwargs)

    def __call__(self, *args, **kwargs):
        return self.azure_chat_open_ai.invoke(*args, **kwargs)


class LLMWrapper(metaclass=ABCMeta):  # LLMWrapper(ABC):
    """
    Formal interface for LLM Wrapper. It is using LLMModel.
    """

    def __init__(
        self,
        model: LLMModel,
    ):
        """Create instance."""
        self.model = model

    @abc.abstractmethod
    def invoke_chain(self, *args, **kwargs):
        """Invoke chain."""


class LangchainLLMWrapper(LLMWrapper):
    """Wrapper for Langchain LLMs."""

    def __init__(
        self,
        model: LangchainLLM,
        prompt_template: ChatPromptTemplate,
        parser: PydanticOutputParser,
        **kwargs,
    ):
        """Create instance."""
        super().__init__(model)
        if not isinstance(model, LLMModel):
            raise Exception("Model is not an instance of LLMModel")
        self.prompt_template = prompt_template
        self.parser: PydanticOutputParser = parser
        self.static_kwargs = kwargs

    def invoke_chain(self, data: str, **kwargs):
        """

        :param sample_image:
        :param kwargs:
        :return:
        """

        chain = self.prompt_template | self.model | extract_json | self.parser
        invoke_args = (
            kwargs
            | self.static_kwargs
            | {
                "data": data,
                "format_instructions": self.parser.get_format_instructions(),
            }
        )

        return chain.invoke(invoke_args)


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()

    llm_model: LangchainLLM = LangchainLLM(
        AzureChatOpenAI(
            azure_deployment="gpt-4o-2024-08-06",
            request_timeout=300,
            max_retries=2,
            temperature=1,
            seed=12345,
            top_p=0.1,
            azure_endpoint=os.getenv("GPTEAL_API_URL"),
            openai_api_key=os.getenv("GPTEAL_API_KEY"),
        )
    )

    class Model(BaseModel):
        """Represents a logo check result on whether given image is a logo and contains an icon."""

        result: int = Field(
            description="integer result",
        )

    prompt_template = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """You are calculator. 

    {system_prompt_check_specific}
    """,
            ),
            (
                "user",
                [
                    {
                        "type": "text",
                        "text": "Your task: `{data}`. {format_instructions}",
                    },
                ],
            ),
        ]
    )
    parser = PydanticOutputParser(pydantic_object=Model)
    langchain_llm = LangchainLLMWrapper(
        model=llm_model, prompt_template=prompt_template, parser=parser
    )
    result = langchain_llm.invoke_chain(
        "1+1", system_prompt_check_specific="Please calculate carefully."
    )
    print(result)
