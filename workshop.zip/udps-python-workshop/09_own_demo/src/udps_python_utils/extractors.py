from langchain_core.exceptions import OutputParserException
from langchain_core.messages import AIMessage


def extract_json(ai_message: AIMessage | str) -> AIMessage:
    """Extract json surrounded by some rubbish text."""
    if isinstance(ai_message, AIMessage):
        text = ai_message.content
    elif isinstance(ai_message, str):
        text = ai_message
    else:
        raise OutputParserException("ai_message must be of type AIMessage or str")

    if text.strip().startswith("{") and text.strip().endswith("}"):
        return ai_message

    # Apparently matching for r"{.*}" is unsafe, so...
    for i, ch in enumerate(text):
        if ch == "{":
            start = i
            break
    else:
        raise OutputParserException(f"Cannot find opening '{{' in:'{text}'")

    for i, ch in enumerate(text[::-1]):
        if ch == "}":
            end = len(text) - i
            break
    else:
        raise OutputParserException(f"Cannot find closing '}}' in:'{text}'")
    text = text[start:end]

    if isinstance(ai_message, AIMessage):
        ai_message.content = text
    elif isinstance(ai_message, str):
        ai_message = text

    return ai_message
