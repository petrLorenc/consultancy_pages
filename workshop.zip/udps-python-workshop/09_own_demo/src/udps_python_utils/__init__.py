"""
Why to use __init__.py?

Backward Compatibility: Including __init__.py ensures compatibility with older versions of Python that do not support implicit namespace packages.
Explicit is Better than Implicit: Following the Zen of Python, having an __init__.py file makes it explicit that the directory is intended to be a package.
Package Initialization: The __init__.py file can be used to execute initialization code for the package or to set up the package namespace.
Control Over Imports: It allows you to control what is imported when the package is imported, by defining the __all__ list.
Avoiding Ambiguity: It helps avoid ambiguity in cases where directories might be mistaken for packages.
"""

from udps_python_utils.llm import (
    LangchainLLM,
    LangchainLLMWrapper,
    LLMModel,
    LLMWrapper,
)

# relative imports -> better portability - good when think about moving the package to another location
# from udps_python_utils.observability import Singleton
# from .observability.wrapper import ObservabilityOrchestrator

"""
The __all__ list in a Python module or package specifies the public symbols that 
the module or package exports. When from module import * is used, 
only the names listed in __all__ will be imported. 
This helps control the namespace and avoid importing unintended symbols.
"""

__all__ = ["LangchainLLM", "LLMModel", "LLMWrapper", "LangchainLLMWrapper"]
