class MyLazyDict(dict):
    def __getitem__(self, item):
        value = dict.__getitem__(self, item)
        print(value.__name__)
        if not isinstance(value, int):
            function = value
            value = function()
            dict.__setitem__(self, item, value)
        return value
