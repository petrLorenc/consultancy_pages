import logging
import os


def setup_logging(
    logger_name: str = "", log_level=logging.getLevelName(os.getenv("LOG", "INFO"))
):
    """
    Setup logging configuration
    :param logger_name: optional logger name
    :param log_level: optional log level, INFO by default
    :return: logger object
    """
    logger = logging.getLogger(logger_name)
    logging.basicConfig()
    logger.setLevel(log_level)
    return logger
