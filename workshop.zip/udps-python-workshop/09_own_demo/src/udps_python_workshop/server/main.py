import os

import uvicorn
from dotenv import load_dotenv
from fastapi import Depends, FastAPI

load_dotenv()

from udps_python_workshop.server.dependencies import get_query_token
from udps_python_workshop.server.routers import scores

app = FastAPI(dependencies=[Depends(get_query_token)])


app.include_router(scores.router)


@app.get("/")
async def root():
    return {"message": "Hello Bigger Applications!"}


if __name__ == "__main__":
    print("Starting server...")
    print("Port:", os.getenv("PORT", 9999), "Host:", os.getenv("HOST", "0.0.0.0"))
    from dotenv import load_dotenv

    load_dotenv()
    uvicorn.run(
        app,
        host=os.getenv("HOST", "0.0.0.0"),
        port=os.getenv("PORT", 9999),
        reload=os.getenv("DEBUG", False),
    )
