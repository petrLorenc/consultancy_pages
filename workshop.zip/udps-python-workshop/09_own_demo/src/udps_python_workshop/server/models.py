from pydantic import BaseModel, Field


# Text to validate
class ValidationInput(BaseModel):
    text: str


class ValidationOutput(BaseModel):
    """Represents a logo check result on whether given image is a logo and contains an icon."""

    fluency_score: int = Field(
        description="How the text is fluent (1-10), 10 is the best",
        default=0,
    )

    correctness_score: int = Field(
        description="How the text is correct (1-10), 10 is the best",
    )

    grammar_score: int = Field(
        description="How the text is grammatically correct (1-10), 10 is the best",
    )

    spelling_errors: list = Field(description="Spelling errors", default_factory=list)
