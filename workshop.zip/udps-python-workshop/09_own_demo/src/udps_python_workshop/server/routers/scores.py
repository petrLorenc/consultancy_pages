from fastapi import APIRouter

from udps_python_workshop.common.logger import setup_logging
from udps_python_workshop.server.logic.validation import validate_string
from udps_python_workshop.server.models import ValidationInput, ValidationOutput

logger = setup_logging(__name__)

router = APIRouter(
    prefix="/scores",
    tags=["validate"],
    responses={404: {"description": "Not found"}},
)


@router.post(
    "/validate",
    tags=["validate"],
    response_model=ValidationOutput,
    responses={403: {"description": "Operation forbidden"}},
)
async def validate(validation_input: ValidationInput):
    logger.debug("Validating input: %s", validation_input.text)
    validation_output = validate_string(validation_input.text)
    logger.debug("Validation output: %s", validation_output)
    return validation_output
