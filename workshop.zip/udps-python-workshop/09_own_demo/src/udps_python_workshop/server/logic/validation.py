import os

from langchain.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI

from udps_python_utils import LangchainLLM, LangchainLLMWrapper
from udps_python_workshop.server.models import ValidationOutput

models = {
    "gpt-4o-2024-08-06": LangchainLLM(
        AzureChatOpenAI(
            openai_api_version="2023-05-15",
            azure_deployment="gpt-4o-2024-08-06",
            request_timeout=300,
            max_retries=2,
            temperature=0,
            seed=12345,
            top_p=0.1,
            azure_endpoint=os.getenv("GPTEAL_API_URL", ""),
            openai_api_key=os.getenv("GPTEAL_API_KEY", ""),
        )
    )
}


prompt_template = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """You are linguistic type of person with a strong feeling for details. 

    {system_prompt_check_specific}
    """,
        ),
        (
            "user",
            [
                {
                    "type": "text",
                    "text": "Input data: `{data}`. {format_instructions}",
                },
            ],
        ),
    ]
)


def validate_string(
    text: str, model: LangchainLLM = models.get("gpt-4o-2024-08-06")
) -> ValidationOutput:
    parser = PydanticOutputParser(pydantic_object=ValidationOutput)
    langchain_llm = LangchainLLMWrapper(
        model=model, prompt_template=prompt_template, parser=parser
    )
    result: ValidationOutput = langchain_llm.invoke_chain(
        text,
        system_prompt_check_specific="Let's think step by step and provide reasoning before the output JSON.",
    )
    return result
