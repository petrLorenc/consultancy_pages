import pytest

from udps_python_utils import LangchainLLM
from udps_python_workshop.server.models import ValidationOutput

"""
In pytest, the scope of a fixture defines how long the fixture will be active and when it will be set up and torn down. The available scopes are:
function: The default scope; the fixture is created and destroyed for each test function.
class: The fixture is set up once per test class and shared among all test methods in that class.
module: The fixture is created once per module and shared among all tests in that module.
package: The fixture is set up once per package.
session: The fixture is created once per test session and shared across all tests. 
5

Understanding these scopes helps in managing resources efficiently during testing.
"""


@pytest.fixture(scope="session")
def possible_output() -> dict:
    """
    Fixture to provide a possible output for the test.
    :return:
    """
    return ValidationOutput(
        fluency_score=50,
        correctness_score=50,
        grammar_score=50,
    ).model_dump()


@pytest.fixture(scope="session")
def langchain_llm() -> LangchainLLM:
    """

    :return:
    """
    return LangchainLLM(None)