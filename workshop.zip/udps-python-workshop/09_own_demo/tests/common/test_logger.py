import logging

from udps_python_workshop.common.logger import setup_logging


def test_setup_logging():
    logger_name = "test_logger"
    log_level = logging.DEBUG
    logger = setup_logging(logger_name, log_level)
    assert logger.name == logger_name
    assert logger.level == log_level
