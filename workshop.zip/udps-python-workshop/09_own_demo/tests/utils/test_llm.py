from unittest.mock import patch

import pytest

from udps_python_utils import LangchainLLM, LLMModel, LangchainLLMWrapper

return_model = {
    'correctness_score': 50,
    'fluency_score': 50,
    'grammar_score': 50,
}


@patch("udps_python_utils.LangchainLLM.invoke", return_value=return_model)
def test_langchain_llm_invoke(mocker, langchain_llm):
    # Call the invoke method
    result = langchain_llm.invoke(None)

    # Assert the expected output
    assert result == return_model
