# test_validation.py
import json
from unittest.mock import patch

from udps_python_utils import LangchainLLM
from udps_python_workshop.server.logic.validation import validate_string
from udps_python_workshop.server.models import ValidationOutput


@patch("langchain_openai.AzureChatOpenAI")
def test_validate_string(azure_chat_openai, possible_output):
    return_model = possible_output

    azure_chat_openai.invoke.return_value = json.dumps(return_model)

    # Create an instance of LangchainLLM
    llm = LangchainLLM(azure_chat_openai)

    # Test input
    test_text = "This is a test string."

    # Call the function
    result = validate_string(test_text, llm)

    # Assert the expected output
    assert result == ValidationOutput(**possible_output)

