# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = "Workshop"
copyright = "2025, Petr Lorenc (APEX CTO)"
author = "Petr Lorenc (APEX CTO)"

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = [
    "myst_parser",
    "sphinx_design",
    "autodoc2",
    "sphinx_copybutton",
    "sphinx_markdown_builder",
]

autodoc2_packages = [
    "../../src/udps_python_utils",
    "../../src/udps_python_workshop",
]

templates_path = ["_templates"]
exclude_patterns = ["build/*"]

myst_enable_extensions = ["colon_fence"]

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

# html_theme = 'alabaster'
html_theme = "furo"
html_static_path = ["_static"]
html_theme_options = {
    "announcement": "<em>Work in progress!</em>!",
}
master_doc = "main"
