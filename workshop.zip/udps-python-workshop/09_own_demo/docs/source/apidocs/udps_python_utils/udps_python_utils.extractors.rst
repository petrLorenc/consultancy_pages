:py:mod:`udps_python_utils.extractors`
======================================

.. py:module:: udps_python_utils.extractors

.. autodoc2-docstring:: udps_python_utils.extractors
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`extract_json <udps_python_utils.extractors.extract_json>`
     - .. autodoc2-docstring:: udps_python_utils.extractors.extract_json
          :summary:

API
~~~

.. py:function:: extract_json(ai_message: langchain_core.messages.AIMessage | str) -> langchain_core.messages.AIMessage
   :canonical: udps_python_utils.extractors.extract_json

   .. autodoc2-docstring:: udps_python_utils.extractors.extract_json
