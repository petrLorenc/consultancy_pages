:py:mod:`udps_python_utils.llm`
===============================

.. py:module:: udps_python_utils.llm

.. autodoc2-docstring:: udps_python_utils.llm
   :allowtitles:

Module Contents
---------------

Classes
~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`LLMModel <udps_python_utils.llm.LLMModel>`
     - .. autodoc2-docstring:: udps_python_utils.llm.LLMModel
          :summary:
   * - :py:obj:`LangchainLLM <udps_python_utils.llm.LangchainLLM>`
     - .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLM
          :summary:
   * - :py:obj:`LLMWrapper <udps_python_utils.llm.LLMWrapper>`
     - .. autodoc2-docstring:: udps_python_utils.llm.LLMWrapper
          :summary:
   * - :py:obj:`LangchainLLMWrapper <udps_python_utils.llm.LangchainLLMWrapper>`
     - .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLMWrapper
          :summary:

API
~~~

.. py:class:: LLMModel
   :canonical: udps_python_utils.llm.LLMModel

   Bases: :py:obj:`typing.Protocol`

   .. autodoc2-docstring:: udps_python_utils.llm.LLMModel

   .. py:method:: invoke(*args, **kwargs)
      :canonical: udps_python_utils.llm.LLMModel.invoke

      .. autodoc2-docstring:: udps_python_utils.llm.LLMModel.invoke

   .. py:method:: __call__(*args, **kwargs)
      :canonical: udps_python_utils.llm.LLMModel.__call__

      .. autodoc2-docstring:: udps_python_utils.llm.LLMModel.__call__

.. py:class:: LangchainLLM(azure_chat_open_ai: langchain_openai.AzureChatOpenAI)
   :canonical: udps_python_utils.llm.LangchainLLM

   .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLM

   .. rubric:: Initialization

   .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLM.__init__

   .. py:method:: invoke(*args, **kwargs)
      :canonical: udps_python_utils.llm.LangchainLLM.invoke

      .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLM.invoke

   .. py:method:: __call__(*args, **kwargs)
      :canonical: udps_python_utils.llm.LangchainLLM.__call__

      .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLM.__call__

.. py:class:: LLMWrapper(model: udps_python_utils.llm.LLMModel)
   :canonical: udps_python_utils.llm.LLMWrapper

   .. autodoc2-docstring:: udps_python_utils.llm.LLMWrapper

   .. rubric:: Initialization

   .. autodoc2-docstring:: udps_python_utils.llm.LLMWrapper.__init__

   .. py:method:: invoke_chain(*args, **kwargs)
      :canonical: udps_python_utils.llm.LLMWrapper.invoke_chain
      :abstractmethod:

      .. autodoc2-docstring:: udps_python_utils.llm.LLMWrapper.invoke_chain

.. py:class:: LangchainLLMWrapper(model: udps_python_utils.llm.LangchainLLM, prompt_template: langchain_core.prompts.ChatPromptTemplate, parser: langchain.output_parsers.PydanticOutputParser, **kwargs)
   :canonical: udps_python_utils.llm.LangchainLLMWrapper

   Bases: :py:obj:`udps_python_utils.llm.LLMWrapper`

   .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLMWrapper

   .. rubric:: Initialization

   .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLMWrapper.__init__

   .. py:method:: invoke_chain(data: str, **kwargs)
      :canonical: udps_python_utils.llm.LangchainLLMWrapper.invoke_chain

      .. autodoc2-docstring:: udps_python_utils.llm.LangchainLLMWrapper.invoke_chain
