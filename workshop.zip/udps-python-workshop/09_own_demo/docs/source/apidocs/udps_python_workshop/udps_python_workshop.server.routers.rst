:py:mod:`udps_python_workshop.server.routers`
=============================================

.. py:module:: udps_python_workshop.server.routers

.. autodoc2-docstring:: udps_python_workshop.server.routers
   :allowtitles:

Submodules
----------

.. toctree::
   :titlesonly:
   :maxdepth: 1

   udps_python_workshop.server.routers.scores
