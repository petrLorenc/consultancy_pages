:py:mod:`udps_python_workshop.server.logic.validation`
======================================================

.. py:module:: udps_python_workshop.server.logic.validation

.. autodoc2-docstring:: udps_python_workshop.server.logic.validation
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`validate_string <udps_python_workshop.server.logic.validation.validate_string>`
     - .. autodoc2-docstring:: udps_python_workshop.server.logic.validation.validate_string
          :summary:

Data
~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`models <udps_python_workshop.server.logic.validation.models>`
     - .. autodoc2-docstring:: udps_python_workshop.server.logic.validation.models
          :summary:
   * - :py:obj:`prompt_template <udps_python_workshop.server.logic.validation.prompt_template>`
     - .. autodoc2-docstring:: udps_python_workshop.server.logic.validation.prompt_template
          :summary:

API
~~~

.. py:data:: models
   :canonical: udps_python_workshop.server.logic.validation.models
   :value: None

   .. autodoc2-docstring:: udps_python_workshop.server.logic.validation.models

.. py:data:: prompt_template
   :canonical: udps_python_workshop.server.logic.validation.prompt_template
   :value: 'from_messages(...)'

   .. autodoc2-docstring:: udps_python_workshop.server.logic.validation.prompt_template

.. py:function:: validate_string(text: str, model: udps_python_utils.LangchainLLM = models.get('gpt-4o-2024-08-06')) -> udps_python_workshop.server.models.ValidationOutput
   :canonical: udps_python_workshop.server.logic.validation.validate_string

   .. autodoc2-docstring:: udps_python_workshop.server.logic.validation.validate_string
