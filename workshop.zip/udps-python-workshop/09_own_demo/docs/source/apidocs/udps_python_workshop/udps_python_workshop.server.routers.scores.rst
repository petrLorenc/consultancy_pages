:py:mod:`udps_python_workshop.server.routers.scores`
====================================================

.. py:module:: udps_python_workshop.server.routers.scores

.. autodoc2-docstring:: udps_python_workshop.server.routers.scores
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`validate <udps_python_workshop.server.routers.scores.validate>`
     - .. autodoc2-docstring:: udps_python_workshop.server.routers.scores.validate
          :summary:

Data
~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`logger <udps_python_workshop.server.routers.scores.logger>`
     - .. autodoc2-docstring:: udps_python_workshop.server.routers.scores.logger
          :summary:
   * - :py:obj:`router <udps_python_workshop.server.routers.scores.router>`
     - .. autodoc2-docstring:: udps_python_workshop.server.routers.scores.router
          :summary:

API
~~~

.. py:data:: logger
   :canonical: udps_python_workshop.server.routers.scores.logger
   :value: 'setup_logging(...)'

   .. autodoc2-docstring:: udps_python_workshop.server.routers.scores.logger

.. py:data:: router
   :canonical: udps_python_workshop.server.routers.scores.router
   :value: 'APIRouter(...)'

   .. autodoc2-docstring:: udps_python_workshop.server.routers.scores.router

.. py:function:: validate(validation_input: udps_python_workshop.server.models.ValidationInput)
   :canonical: udps_python_workshop.server.routers.scores.validate
   :async:

   .. autodoc2-docstring:: udps_python_workshop.server.routers.scores.validate
