:py:mod:`udps_python_workshop.server.logic`
===========================================

.. py:module:: udps_python_workshop.server.logic

.. autodoc2-docstring:: udps_python_workshop.server.logic
   :allowtitles:

Submodules
----------

.. toctree::
   :titlesonly:
   :maxdepth: 1

   udps_python_workshop.server.logic.validation

Package Contents
----------------

Data
~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`__all__ <udps_python_workshop.server.logic.__all__>`
     - .. autodoc2-docstring:: udps_python_workshop.server.logic.__all__
          :summary:

API
~~~

.. py:data:: __all__
   :canonical: udps_python_workshop.server.logic.__all__
   :value: ['validate_string', 'models', 'prompt_template']

   .. autodoc2-docstring:: udps_python_workshop.server.logic.__all__
