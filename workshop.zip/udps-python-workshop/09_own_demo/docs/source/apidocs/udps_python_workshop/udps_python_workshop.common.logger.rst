:py:mod:`udps_python_workshop.common.logger`
============================================

.. py:module:: udps_python_workshop.common.logger

.. autodoc2-docstring:: udps_python_workshop.common.logger
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`setup_logging <udps_python_workshop.common.logger.setup_logging>`
     - .. autodoc2-docstring:: udps_python_workshop.common.logger.setup_logging
          :summary:

API
~~~

.. py:function:: setup_logging(logger_name: str = '', log_level=logging.getLevelName(os.getenv('LOG', 'INFO')))
   :canonical: udps_python_workshop.common.logger.setup_logging

   .. autodoc2-docstring:: udps_python_workshop.common.logger.setup_logging
