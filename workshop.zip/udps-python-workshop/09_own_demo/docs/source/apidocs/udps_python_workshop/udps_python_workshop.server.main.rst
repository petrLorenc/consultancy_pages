:py:mod:`udps_python_workshop.server.main`
==========================================

.. py:module:: udps_python_workshop.server.main

.. autodoc2-docstring:: udps_python_workshop.server.main
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`root <udps_python_workshop.server.main.root>`
     - .. autodoc2-docstring:: udps_python_workshop.server.main.root
          :summary:

Data
~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`app <udps_python_workshop.server.main.app>`
     - .. autodoc2-docstring:: udps_python_workshop.server.main.app
          :summary:

API
~~~

.. py:data:: app
   :canonical: udps_python_workshop.server.main.app
   :value: 'FastAPI(...)'

   .. autodoc2-docstring:: udps_python_workshop.server.main.app

.. py:function:: root()
   :canonical: udps_python_workshop.server.main.root
   :async:

   .. autodoc2-docstring:: udps_python_workshop.server.main.root
