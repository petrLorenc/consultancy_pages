:py:mod:`udps_python_workshop.common`
=====================================

.. py:module:: udps_python_workshop.common

.. autodoc2-docstring:: udps_python_workshop.common
   :allowtitles:

Submodules
----------

.. toctree::
   :titlesonly:
   :maxdepth: 1

   udps_python_workshop.common.logger

Package Contents
----------------

Classes
~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`MyLazyDict <udps_python_workshop.common.MyLazyDict>`
     -

API
~~~

.. py:class:: MyLazyDict()
   :canonical: udps_python_workshop.common.MyLazyDict

   Bases: :py:obj:`dict`

   .. py:method:: __getitem__(item)
      :canonical: udps_python_workshop.common.MyLazyDict.__getitem__
