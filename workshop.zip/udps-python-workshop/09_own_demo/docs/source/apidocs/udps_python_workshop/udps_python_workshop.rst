:py:mod:`udps_python_workshop`
==============================

.. py:module:: udps_python_workshop

.. autodoc2-docstring:: udps_python_workshop
   :allowtitles:

Subpackages
-----------

.. toctree::
   :titlesonly:
   :maxdepth: 3

   udps_python_workshop.server
   udps_python_workshop.common
