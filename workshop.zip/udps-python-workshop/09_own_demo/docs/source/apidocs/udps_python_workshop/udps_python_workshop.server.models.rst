:py:mod:`udps_python_workshop.server.models`
============================================

.. py:module:: udps_python_workshop.server.models

.. autodoc2-docstring:: udps_python_workshop.server.models
   :allowtitles:

Module Contents
---------------

Classes
~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`ValidationInput <udps_python_workshop.server.models.ValidationInput>`
     -
   * - :py:obj:`ValidationOutput <udps_python_workshop.server.models.ValidationOutput>`
     - .. autodoc2-docstring:: udps_python_workshop.server.models.ValidationOutput
          :summary:

API
~~~

.. py:class:: ValidationInput(/, **data: typing.Any)
   :canonical: udps_python_workshop.server.models.ValidationInput

   Bases: :py:obj:`pydantic.BaseModel`

   .. py:attribute:: text
      :canonical: udps_python_workshop.server.models.ValidationInput.text
      :type: str
      :value: None

      .. autodoc2-docstring:: udps_python_workshop.server.models.ValidationInput.text

.. py:class:: ValidationOutput(/, **data: typing.Any)
   :canonical: udps_python_workshop.server.models.ValidationOutput

   Bases: :py:obj:`pydantic.BaseModel`

   .. autodoc2-docstring:: udps_python_workshop.server.models.ValidationOutput

   .. rubric:: Initialization

   .. autodoc2-docstring:: udps_python_workshop.server.models.ValidationOutput.__init__

   .. py:attribute:: fluency_score
      :canonical: udps_python_workshop.server.models.ValidationOutput.fluency_score
      :type: int
      :value: 'Field(...)'

      .. autodoc2-docstring:: udps_python_workshop.server.models.ValidationOutput.fluency_score

   .. py:attribute:: correctness_score
      :canonical: udps_python_workshop.server.models.ValidationOutput.correctness_score
      :type: int
      :value: 'Field(...)'

      .. autodoc2-docstring:: udps_python_workshop.server.models.ValidationOutput.correctness_score

   .. py:attribute:: grammar_score
      :canonical: udps_python_workshop.server.models.ValidationOutput.grammar_score
      :type: int
      :value: 'Field(...)'

      .. autodoc2-docstring:: udps_python_workshop.server.models.ValidationOutput.grammar_score

   .. py:attribute:: spelling_errors
      :canonical: udps_python_workshop.server.models.ValidationOutput.spelling_errors
      :type: list
      :value: 'Field(...)'

      .. autodoc2-docstring:: udps_python_workshop.server.models.ValidationOutput.spelling_errors
