:py:mod:`udps_python_workshop.server.dependencies`
==================================================

.. py:module:: udps_python_workshop.server.dependencies

.. autodoc2-docstring:: udps_python_workshop.server.dependencies
   :allowtitles:

Module Contents
---------------

Functions
~~~~~~~~~

.. list-table::
   :class: autosummary longtable
   :align: left

   * - :py:obj:`get_token_header <udps_python_workshop.server.dependencies.get_token_header>`
     - .. autodoc2-docstring:: udps_python_workshop.server.dependencies.get_token_header
          :summary:
   * - :py:obj:`get_query_token <udps_python_workshop.server.dependencies.get_query_token>`
     - .. autodoc2-docstring:: udps_python_workshop.server.dependencies.get_query_token
          :summary:

API
~~~

.. py:function:: get_token_header(x_token: typing.Annotated[str, Header()])
   :canonical: udps_python_workshop.server.dependencies.get_token_header
   :async:

   .. autodoc2-docstring:: udps_python_workshop.server.dependencies.get_token_header

.. py:function:: get_query_token(token: str)
   :canonical: udps_python_workshop.server.dependencies.get_query_token
   :async:

   .. autodoc2-docstring:: udps_python_workshop.server.dependencies.get_query_token
