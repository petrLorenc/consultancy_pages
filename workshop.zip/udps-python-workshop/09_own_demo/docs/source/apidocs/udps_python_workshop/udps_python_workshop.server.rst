:py:mod:`udps_python_workshop.server`
=====================================

.. py:module:: udps_python_workshop.server

.. autodoc2-docstring:: udps_python_workshop.server
   :allowtitles:

Subpackages
-----------

.. toctree::
   :titlesonly:
   :maxdepth: 3

   udps_python_workshop.server.routers
   udps_python_workshop.server.logic

Submodules
----------

.. toctree::
   :titlesonly:
   :maxdepth: 1

   udps_python_workshop.server.models
   udps_python_workshop.server.main
   udps_python_workshop.server.dependencies
