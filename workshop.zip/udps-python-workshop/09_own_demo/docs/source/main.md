# Reusable components for GenAI applications

Workshop in progress. This is the main page of your project which can go into Github Pages if you want. 

This Workshop is separated into 3 parts.

- Introduction to Python (Syntax) - 60m + 10m reserve + 10m coffe break
  - Jupyter Notebook (over Docker) or locally
  - lecture format with time for experiments
  - See below for more details ...
  
- Virtual Environment - 20 mins + 10m reserve + 10m coffe break
  - Where the Python looks for modules
  - Docker container with UV installed or locally
  - lecture format with time for experiments
  - [ ] Python Virtual Environment with focus on UV
  - [ ] Structure/Packaging - setuptools, pyproject.toml, setup.cfg, MANIFEST.in

- Tools/Libraries on real project - 40m + 20m discussion + conclusion
  - Assignments over real project
  - [ ] Tools for better development - pytest, black, flake8, mypy, isort
  - [ ] Tools for debugging - PyCharm
  - [ ] Tools for documentation - Sphinx
  - [ ] Libraries - Langchain, fastAPI, asyncio, pydantic 
- 
- Keep for future
  - pre-commit
  - [ ] Tools to measure performance - cProfile, timeit, memory_profiler
  - [ ] Tools for debugging - VSCode
  - [ ] Tools for packaging - setuptools, wheel, twine
  - [ ] Tools for experimentation - Jupyter Notebook

```{toctree}
Main page <main.md>
Example Observability <utils.md>
Example Validation <workshop.md>
```
