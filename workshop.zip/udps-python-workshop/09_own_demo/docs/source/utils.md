# Example of usage

## API

```{autodoc2-summary}
:renderer: myst

~udps_python_utils.llm
```
