import logging
import asyncio

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.prompts import base

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# 1. Create a FastMCP server instance
mcp = FastMCP(
    name="sum_two_numbers_mcp_server",
)

# 2. Define a tool that sums two numbers
@mcp.tool(
    name="sum_two_numbers",
    description="A tool that sums two numbers.",
)
async def sum_two_numbers_tool(a: int, b: int) -> int:
    """A tool that sums two numbers."""
    logger.debug(f"The sum of {a} and {b} is {a + b} (Calculated by MCP server).")
    return a + b

@mcp.prompt(title="Code Review")
def review_code(code: str) -> str:
    return f"Please review this code:\n\n{code}"


@mcp.prompt(title="Debug Assistant")
def debug_error(error: str) -> list[base.Message]:
    return [
        base.UserMessage("I'm seeing this error:"),
        base.UserMessage(error),
        base.AssistantMessage("I'll help debug that. What have you tried so far?"),
    ]

@mcp.resource("file://documents/{name}")
def read_document(name: str) -> str:
    """Read a document by name."""
    # This would normally read from disk
    return f"Content of {name}"


@mcp.resource("config://settings")
def get_settings() -> str:
    """Get application settings."""
    return """{
  "theme": "dark",
  "language": "en",
  "debug": false
}"""


if __name__ == "__main__":
    # 3. Run the FastMCP server
    print("Starting MCP server...")
    # mcp.run(transport="stdio")
    mcp.run(transport="streamable-http")