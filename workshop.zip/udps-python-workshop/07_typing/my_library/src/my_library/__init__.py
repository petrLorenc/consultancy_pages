def hello() -> str:
    return "Hello from my-library!"

def add(a, b):
    return a + b