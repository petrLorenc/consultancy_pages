fn sum_list(numbers: &[i32]) -> i32 {
    numbers.iter().sum()
}

fn main() {
    let numbers = vec![1, 2, 3, 4, 5];
    println!("Sum: {}", sum_list(&numbers)); // Output: Sum: 15
}