from typing import Any, Union, Optional, Tuple, Callable, Sequence, TypeVar # some of them can be imported from collections.abc in 3.10+

class Object: ...
class Shape(Object): ...
class Triangle(Shape): ...
class Square(Shape): ...

T = TypeVar("T", bound=Triangle)

def foo(x: T) -> T:
    return x

first_use = foo(Triangle()) 
second_use = foo(Square())  
third_use = foo(Shape())     
fourth_use = foo(Object())  