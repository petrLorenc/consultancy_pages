def main() -> None:
    print("Hello from 03-playground-libraries!")
