# some code
def main():
    print("Hello, World!")
    