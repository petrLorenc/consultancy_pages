# Conda + Poetry ("official" way)

This is a page I found in forge.merck.com. It is more on Data Science side, but it is also a good start for Python development.

I will leave it here as second point of view.

# Prerequisites
## Windows
1. Python 3 (Windows only)

    Install Python from the Software center
    ![Python](docs/imgs/python-3.7.3.png)

2. Miniforge

    Install Miniforge from the Software center
    ![Miniforge](docs/imgs/miniforge.png)

3. [Configure .condarc](https://share.merck.com/spaces/BP/pages/549618381/Configuration+for+local+python+development+-+conda+and+pip)
    ```
    Invoke-WebRequest https://go.merck.com/conda-settings -Method Get -ContentType "text/plain; charset=utf-8" -OutFile "$env:APPDATA\.condarc"
    ```

## Mac
1. [Miniforge](https://share.merck.com/display/BP/How+to+properly+setup+Python+environment)
    ```bash
    # Remove any existing installation of miniconda from your system
    rm -rf /miniconda3
    rm -rf ~/miniconda3 ~/.condarc ~/.conda

    # cURL
    curl -L -O "https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-$(uname)-$(uname -m).sh"
    bash Miniforge3-$(uname)-$(uname -m).sh
    ```
2. [Configure .condarc](https://share.merck.com/spaces/BP/pages/549618381/Configuration+for+local+python+development+-+conda+and+pip)
    ```bash
    # Remove existing .condarc
    conda config --show-sources
    rm ~/miniforge3/.condarc

    curl -sSL 'http://go.merck.com/conda-settings' > ${HOME}/.condarc
    ```

# Setup
## Create Project
1. Create conda environment `conda create -n py3.13 python=3.13 virtualenv`
2. Activate environment `conda activate py3.13`
3. Install **poetry** `pip install poetry`
4. Create project `poetry new python-test`
5. Navigate to project `cd python-test`
6. Update **pyproject.toml** and set `package-mode = false` in **[tool.poetry]**

## Virtual Environment
1. Create new virtual environment `python -m virtualenv .venv`
2. Activate virtual environment `source .venv/bin/activate`
3. With virtual environment, conda environment is no longer needed `conda deactivate`
4. Install **poetry** `pip install poetry`
5. Ensure VSCode is using the right Python interpreter
    ![Python Interpreter](docs/imgs/python-interpreter.jpg)

## Install Dependencies
1. Install libraries `poetry install`
2. Add libraries `poetry add <library>`
3. Add dev libraries `poetry add -D <library>`

## Formatting with pre-commit
1. Add pre-commit `poetry add -D pre-commit`
2. Install pre-commit hook `pre-commit install`
3. Manual trigger with `pre-commit run --all-files`

## Testing
1. Install pytest `poetry add -D moto pytest pytest-cov`
2. Enable Testing: Pytest Enabled in VSCode
3. View detected tests with file name `*test*.py`