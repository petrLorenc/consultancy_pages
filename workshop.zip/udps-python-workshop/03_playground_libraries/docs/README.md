Tools/Libraries on real project - 40m + 20m discussion + conclusion

Assignments over real project
Tools for better development - pytest, black, flake8, mypy, isort
Tools for debugging - PyCharm
Tools for documentation - Sphinx
Libraries - Langchain, fastAPI, asyncio, pydantic