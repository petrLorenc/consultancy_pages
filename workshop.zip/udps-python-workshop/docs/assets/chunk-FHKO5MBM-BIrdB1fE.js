var t;import{_ as s}from"./mermaid-0ClPHFIM.js";var r=(t=class{constructor(i){this.init=i,this.records=this.init()}reset(){this.records=this.init()}},s(t,"ImperativeState"),t);export{r as I};
