function c(e){for(var n=e.length/6|0,a=new Array(n),r=0;r<n;)a[r]="#"+e.slice(6*r,6*++r);return a}export{c};
